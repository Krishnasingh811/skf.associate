<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    protected $fillable = [
        'name','phone','email','aadhar','pan','loan_type','amount_requested','assigned_to','source','status','bank_suggested','cibil_score'
    ];

    public function documents(){ return $this->hasMany(LeadDocument::class); }
}
