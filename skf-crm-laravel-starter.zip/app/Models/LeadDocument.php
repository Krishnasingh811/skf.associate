<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeadDocument extends Model
{
    protected $fillable = ['lead_id','doc_type','file_path','uploaded_by','verified','expiry_date'];

    public function lead(){ return $this->belongsTo(Lead::class); }
}
