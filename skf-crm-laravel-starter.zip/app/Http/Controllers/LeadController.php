<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Lead;
use App\Models\LeadDocument;

class LeadController extends Controller
{
    public function index(){
        $leads = Lead::orderBy('created_at','desc')->paginate(15);
        return view('leads.index', compact('leads'));
    }

    public function create(){ return view('leads.create'); }

    public function store(Request $r){
        $data = $r->validate([
            'name'=>'required', 'phone'=>'required', 'loan_type'=>'nullable', 'amount_requested'=>'nullable|numeric'
        ]);
        $lead = Lead::create($data + ['assigned_to'=>auth()->id()]);
        return redirect()->route('leads.show',$lead->id)->with('success','Lead created');
    }

    public function show($id){
        $lead = Lead::with('documents')->findOrFail($id);
        return view('leads.show', compact('lead'));
    }

    public function edit($id){ $lead = Lead::findOrFail($id); return view('leads.edit', compact('lead')); }

    public function update(Request $r,$id){
        $lead = Lead::findOrFail($id);
        $lead->update($r->only(['name','phone','email','loan_type','amount_requested','status','bank_suggested']));
        return back()->with('success','Updated');
    }

    public function destroy($id){ Lead::destroy($id); return redirect()->route('leads.index'); }

    // document upload
    public function uploadDocument(Request $r,$id){
        $r->validate(['doc'=>'required|file|max:5120','doc_type'=>'required']);
        $lead = Lead::findOrFail($id);
        $path = $r->file('doc')->store('lead_docs','public');
        $doc = LeadDocument::create(['lead_id'=>$lead->id,'doc_type'=>$r->doc_type,'file_path'=>$path,'uploaded_by'=>auth()->id()]);
        return back()->with('success','Document uploaded');
    }
}
