<?php
namespace App\Http\Controllers;
use App\Models\Lead;

class DashboardController extends Controller
{
    public function index(){
        $total = Lead::count();
        $new = Lead::where('status','new')->count();
        $login = Lead::where('status','login')->count();
        $disbursed = Lead::where('status','disbursed')->count();
        return view('dashboard', compact('total','new','login','disbursed'));
    }
}
