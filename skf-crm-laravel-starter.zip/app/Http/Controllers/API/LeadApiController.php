<?php
namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Lead;

class LeadApiController extends Controller
{
    public function index(){ return response()->json(Lead::latest()->paginate(20)); }
    public function store(Request $r){
        $data = $r->validate(['name'=>'required','phone'=>'required']);
        $lead = Lead::create($data + ['assigned_to'=>auth()->id()]);
        return response()->json($lead,201);
    }
}
