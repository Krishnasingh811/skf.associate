<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class AuthController extends Controller
{
    public function showLogin(){ return view('auth.login'); }

    public function login(Request $r){
        $creds = $r->only('email','password');
        if(Auth::attempt($creds)){
            return redirect('/dashboard');
        }
        return back()->withErrors(['Invalid credentials']);
    }

    public function logout(){ Auth::logout(); return redirect('/login'); }
}
