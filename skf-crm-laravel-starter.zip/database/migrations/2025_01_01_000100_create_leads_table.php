<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLeadsTable extends Migration
{
    public function up(){
        Schema::create('leads', function(Blueprint $table){
            $table->id();
            $table->string('name');
            $table->string('phone');
            $table->string('email')->nullable();
            $table->string('aadhar')->nullable();
            $table->string('pan')->nullable();
            $table->string('loan_type')->nullable();
            $table->decimal('amount_requested',15,2)->nullable();
            $table->unsignedBigInteger('assigned_to')->nullable();
            $table->string('source')->nullable();
            $table->string('status')->default('new');
            $table->string('bank_suggested')->nullable();
            $table->integer('cibil_score')->nullable();
            $table->timestamps();
        });
    }
    public function down(){ Schema::dropIfExists('leads'); }
}
