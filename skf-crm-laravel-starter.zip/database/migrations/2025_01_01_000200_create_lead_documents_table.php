<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLeadDocumentsTable extends Migration
{
    public function up(){
        Schema::create('lead_documents', function(Blueprint $table){
            $table->id();
            $table->unsignedBigInteger('lead_id');
            $table->string('doc_type');
            $table->string('file_path');
            $table->unsignedBigInteger('uploaded_by')->nullable();
            $table->boolean('verified')->default(false);
            $table->date('expiry_date')->nullable();
            $table->timestamps();

            $table->foreign('lead_id')->references('id')->on('leads')->onDelete('cascade');
        });
    }
    public function down(){ Schema::dropIfExists('lead_documents'); }
}
