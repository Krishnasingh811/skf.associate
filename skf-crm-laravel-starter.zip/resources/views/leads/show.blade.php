@extends('layouts.app')
@section('content')
<h2>Lead #{{ $lead->id }} - {{ $lead->name }}</h2>
<p>Phone: {{ $lead->phone }}</p>
<p>Loan: {{ $lead->loan_type }} | Amount: {{ $lead->amount_requested }}</p>
<h3>Documents</h3>
<ul>@foreach($lead->documents as $d)<li>{{ $d->doc_type }} - <a href="/storage/{{ $d->file_path }}">Open</a> - Verified: {{ $d->verified ? 'Yes' : 'No' }}</li>@endforeach</ul>
<h3>Upload</h3>
<form method="POST" action="/leads/{{ $lead->id }}/upload-document" enctype="multipart/form-data">@csrf
  <input type="text" name="doc_type" placeholder="Doc type (PAN/AADHAR)" required />
  <input type="file" name="doc" required />
  <button type="submit">Upload</button>
</form>
@endsection
