@extends('layouts.app')
@section('content')
<h2>Leads</h2>
<a href="/leads/create">New Lead</a>
<table border="1" width="100%"><tr><th>ID</th><th>Name</th><th>Phone</th><th>Loan</th><th>Status</th><th>Action</th></tr>
@foreach($leads as $l)
<tr>
  <td>{{ $l->id }}</td>
  <td>{{ $l->name }}</td>
  <td>{{ $l->phone }}</td>
  <td>{{ $l->loan_type }}</td>
  <td>{{ $l->status }}</td>
  <td><a href="/leads/{{ $l->id }}">View</a> | <a href="/leads/{{ $l->id }}/edit">Edit</a></td>
</tr>
@endforeach
</table>
{{ $leads->links() }}
@endsection
