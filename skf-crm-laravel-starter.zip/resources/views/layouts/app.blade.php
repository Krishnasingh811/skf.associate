<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>SKF CRM</title>
  <link rel="stylesheet" href="/css/app.css">
</head>
<body>
  <nav>
    <a href="/dashboard">Dashboard</a> | <a href="/leads">Leads</a> | <form method="POST" action="/logout" style="display:inline">@csrf <button type="submit">Logout</button></form>
  </nav>
  <main style="padding:20px">@if(session('success'))<div style="background:#e0ffe0;padding:8px">{{ session('success') }}</div>@endif @yield('content')</main>
</body>
</html>
