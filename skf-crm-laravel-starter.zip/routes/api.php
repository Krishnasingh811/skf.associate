<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\LeadApiController;

Route::middleware('auth:sanctum')->group(function(){
    Route::get('/leads', [LeadApiController::class,'index']);
    Route::post('/leads', [LeadApiController::class,'store']);
});
